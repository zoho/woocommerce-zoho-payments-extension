<?php
/*
Plugin Name: Zoho Payments
Plugin URI: https://www.zoho.com/in/payments/
Description: Zoho Payments Plugin for Woo Commerce.
Version: 1.0
Author: ZPay
Author URI: https://www.zoho.com/in/payments/
Copyright: © 2024, Zoho Pay. All rights reserved.
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) )
{
    exit; 
}

// Define constants
define('ZOHO_PAYMENT_GATEWAY_VERSION', '0.1.0');
define('ZOHO_PAYMENT_GATEWAY_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('ZOHO_PAYMENT_GATEWAY_DOMAIN', 'woocommerce-gateway-zoho');

// Include the main class file
include_once ZOHO_PAYMENT_GATEWAY_PLUGIN_PATH . 'zoho-payments-api-handler.php';

// Handle disconnect conenction form submission
if (is_admin() && isset($_POST['zpay_disconnect'])) {
    error_log('Disconnecting Zoho - form submitted');
    // Get your settings key (use the same as your gateway)
    $settings = get_option('woocommerce_zpay_settings', []);

    $settings['refresh_token'] = '';
    $settings['access_token'] = '';
    update_option('woocommerce_zpay_settings', $settings);

    add_action('admin_notices', function() {
        echo '<div class="notice notice-success"><p>Zoho disconnected successfully.</p></div>';
    });
}


// Add admin scripts for the settings page
add_action('admin_footer', function() {
    ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var btn = document.getElementById("zpay-disconnect-btn");
            if (btn) {
                btn.addEventListener("click", function() {
                  
                    var form = btn.closest("form") || document.querySelector('form');
                    if (form) {
                    
                        var input = document.createElement("input");
                        input.type = "hidden";
                        input.name = "zpay_disconnect";
                        input.value = "1";
                        form.appendChild(input);
                        form.submit();
                    }
                });
            }
        });
    </script>
    <?php
});

// Enqueue admin scripts and styles for the settings page
add_action('admin_enqueue_scripts', function($hook) {
    if ($hook === 'woocommerce_page_wc-settings' && isset($_GET['section']) && $_GET['section'] === 'zpay') {
        wp_enqueue_script(
            'zpay-eye-toggle',
            plugin_dir_url(__FILE__) . 'assets/js/zpay-eye-toggle.js',
            array('jquery'),
            ZOHO_PAYMENT_GATEWAY_VERSION,
            true
        );
        wp_enqueue_style('dashicons'); // <-- Add this line
    }
});

// Ensure encryption key exists on plugin activation
register_activation_hook(__FILE__, function() {
    // Ensure encryption key exists
    if (!get_option('zpay_encryption_key')) {
        $key = bin2hex(random_bytes(32)); // 64 hex chars = 32 bytes
        add_option('zpay_encryption_key', $key, '', 'no');
    }
});


// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'declare_cart_checkout_blocks_compatibility');
// 2 - Main Function to declare compatibility with cart_checkout_blocks feature 
function declare_cart_checkout_blocks_compatibility()  {
   // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
      
        if (version_compare(WC_VERSION, '6.9', '>=')) { 	
            // Declare compatibility for 'cart_checkout_blocks'
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', plugin_dir_path(__FILE__), true);
        } else {
            error_log('WooCommerce version is not compatible');
        }
    } 
	
}


// Hook the custom function to the 'woocommerce_blocks_loaded' action
add_action( 'woocommerce_blocks_loaded', 'oawoo_register_order_approval_payment_method_type' );
// Main function to register the custom payment method with WooCommerce Blocks
function oawoo_register_order_approval_payment_method_type() {
    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'class-zpay-block.php';

    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Zpay_Gateway_Blocks );
        }
    );
}

// Include the gateway class file
add_action('plugins_loaded', 'woocommerce_zpay_init', 0);
// Main function to initialize the gateway
function woocommerce_zpay_init() {

// Check if WooCommerce is active
if (!class_exists('WC_Payment_Gateway')) return;  
    
class WC_ZPay extends WC_Payment_Gateway {

		 // Define properties
		 public $title;
		 public $description;
		 public $instructions;
		 public $client_id;
		 public $client_secret;
		 public $account_id;
		 public $api_key;
		 public $signing_key;
		 public $w_signing_key;
		 public $business;
		 public $business_desc;
		 public $email;
		 public $name;
		 public $order_id;
		 public $user_details;
         public $refresh_token;
		 public $access_token;
		 public $data_center;
         public $redirect_uri;

    // FN-1 Auth url for Zoho OAuth Connect/Disconnect
    public function get_zoho_auth_status_html() {

        $refresh_token = $this->get_option('refresh_token');
        $access_token = $this->get_option('access_token');

        $is_connected = !empty($refresh_token) && !empty($access_token);

        $logo_url = plugin_dir_url(__FILE__) . 'images/zpay-logo.png';
        $connect_url = esc_url($this->get_zoho_oauth_url()); // <-- Add this line

   
        $status_html = $is_connected
        ? '
        <div style="
            display: flex; 
            align-items: center; 
            gap: 12px; 
            margin-bottom: 24px;
        ">
        
            <span style="
                font-weight: 700; 
                color: #27ae60; 
                font-size: 18px;
            ">
                Connected
            </span>
        </div>'
        : '
        <div style="
            display: flex; 
            align-items: center; 
            gap: 12px; 
            margin-bottom: 24px;
        ">
        
            <span style="
                font-weight: 500; 
                color: #e74c3c; 
                font-size: 18px;
            ">
                Not Connected
            </span>
            </br>
            <span style="
                font-weight: 300; 
                color:rgb(15, 14, 14); 
                font-size: 13px;
            ">
            You should remove woocommerce from trusted apps in accounts.zoho.com > Sessions > Connected Apps to connect again
            </span>
        </div>';


        $connect_btn = '<a href="' . $connect_url . '" class="button button-primary" style="font-size: 15px; border-radius: 12px; font-weight: 300; background: #356bb3; color: #fff; border: none;">Connect</a>';

        $disconnect_btn = $is_connected
        ? '<button type="button" id="zpay-disconnect-btn" class="button" style="background:#d3544b;color:#fff;font-size:15px;border-radius:12px;font-weight:300;border:none;">Disconnect</button>'
        : '';

        return '
        <div style="
            background: #fff;
            border-radius: 24px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            max-width: 480px;
            margin: 40px 0;
            border: none;
            font-family: \'Segoe UI\', Arial, sans-serif;
            overflow: hidden;
        ">
            <div style="
                background: #f6f8fa;
                padding: 32px 40px 24px 40px;
                display: flex;
                align-items: center;
                gap: 20px;
                border-bottom: 1px solid #eee;
            ">
                <img src="' . esc_url($logo_url) . '" alt="Zoho Payments" style="height:56px;width:auto;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.08);background:#fff;">
                <span style="font-size:32px;font-weight:700;color:#222;">Zoho Payments</span>
            </div>
            <div style="
                padding: 36px 40px 40px 40px;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 32px;
                background: #fff;
            ">
                ' . $status_html . '
                <div style="display: flex; gap: 24px;">
                    ' . $connect_btn . '
                    ' . $disconnect_btn . '
                </div>
            </div>
        </div>
        ';
    }

    // FN-2 Override process_admin_options to encrypt sensitive fields
	public function process_admin_options() {
    parent::process_admin_options();
    $settings = get_option($this->get_option_key());
    // Encrypt sensitive fields before saving
    foreach ([
        'client_id', 'client_secret', 'api_key', 'signing_key', 'w_signing_key',
       'refresh_token', 'access_token'
    ] as $field) {
        if (!empty($settings[$field]) && strpos($settings[$field], 'ENC:') !== 0) {
            $settings[$field] = 'ENC:' . zpay_encrypt($settings[$field]);
        }}
    update_option($this->get_option_key(), $settings);
    }

    // FN-3 Override get_option to decrypt sensitive fields when accessed in admin
    public function get_option($key, $empty_value = null) {
        $value = parent::get_option($key, $empty_value);
        // Decrypt if needed for display in admin
        if (is_admin() && strpos($value, 'ENC:') === 0) {
            return zpay_decrypt(substr($value, 4));
        }
        return $value;      
    }

    //FN-4 Receipt page to launch Zoho Payments widget
	public function receipt_page($order_id){
		static $executed = false;
		if ($executed) {
			return;
		}
		$executed = true;
		
		$order = wc_get_order($order_id);
		error_log('receipt_page ---------');
	
		$payment_result = $order->get_transaction_id(); // Use stored session ID

		$this->enqueue_zpay_script($order_id, $payment_result);
		echo '<p>'.esc_html__( 'Thank you for your order, Zoho Payments Widget will be launched now', 'zpay' ).'</p>';
	}
	
	//FN-5 Process the payment and return the result
	public function process_payment($order_id) {
        error_log('process_payment ************');
        $order = wc_get_order($order_id);
        // Attempt to get/create the session ID
        $session_id = $order->get_transaction_id(); // Or your logic to create session

        if (empty($session_id)) {
            error_log('Zoho Payments: session_id not created!');
            return array(
                'result' => 'failure',
                'message' => __('Zoho Payments error: Payment session could not be created. Please try again or contact support.', ZOHO_PAYMENT_GATEWAY_DOMAIN),
                'redirect' => wc_get_checkout_url()
            );
        }
        else
        {
            error_log('Zoho Payments transaction id created');
        
        }
	
			return array(
				'result' => 'success',
				'redirect' => add_query_arg(
					array(
						'order-pay' => $order->get_id(),
						'key' => $order->get_order_key(),
						'launch_widget' => 'true'
					),
					$order->get_checkout_payment_url(true)
				)
			);
	}

    //FN-6 Generate encryption key for Zoho Payments
    public function zpay_encrypt_key($order_id, $payment_id) {
   
	$key = hash('sha256', $order_id . $payment_id); // 32 bytes hash key
	$generated_key_wp = wp_generate_password(32, true, true);
    $iv = openssl_random_pseudo_bytes(16); // 16 bytes IV for AES-256-CBC
    $encrypted = openssl_encrypt($key, 'AES-256-CBC', $generated_key_wp, 0, $iv);
  
    // Store IV with encrypted data (base64-encoded)
    return base64_encode($iv . $generated_key_wp);

    }


	/**
	 * Enqueues the Zoho Payments script and initializes the payment widget.
	 *
	 * Processes the payment for pre-orders charged upon release.
	 *
	 * @param WC_Order $order The order object.
	 */
    // FN-7 Enqueue Zoho Payments script and initialize the payment widget
	public function enqueue_zpay_script($order_id,$payment_result) {
		
		// Ensure that we are on the checkout page
		if ( ! is_checkout() ) {
			  error_log('is not checkout page');
		}
		else
		{
			error_log('is checkout page');
		}
	
		
		// Ensure the order is available
		if ( $order_id) {
			$order = wc_get_order( $order_id ); // Get the order object
			
		} else {
			error_log('is checkout order not available test');
			return; // Exit if order is not available
		}

         // Add this line before ob_start()
        $zpay_nonce = wp_create_nonce('wp_rest');
            ob_start(); ?>
        <script src="https://static.zohocdn.com/zpay/zpay-js/v1/zpayments.js"></script> 
        <!-- 	<script src="https://zbooks-cent7-64-3.csez.zohocorpin.com:9090/zpay_js/patch_payment_signature/zpayments.js"></script>-->
            <script>
                function showToast(message) {
        var toast = document.createElement('div');
        toast.textContent = message;
        toast.style.position = 'fixed';
        toast.style.top = '30px'; // Align at top
        toast.style.left = '50%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.background = 'rgba(243, 72, 109, 0.95)'; // Bootstrap danger red, semi-transparent
        toast.style.color = '#fff';
        toast.style.padding = '16px 32px';
        toast.style.borderRadius = '0.5rem'; // Bootstrap rounded
        toast.style.fontSize = '12px';
        toast.style.fontWeight = '500';
        toast.style.boxShadow = '0 2px 8px rgba(0,0,0,0.2)';
        toast.style.zIndex = 9999;
        toast.style.border = '1px solidrgb(237, 96, 110)';
        toast.style.textAlign = 'center';
        toast.style.maxWidth = '90vw';
        toast.style.pointerEvents = 'none';
        document.body.appendChild(toast);
        setTimeout(function() {
            toast.remove();
        }, 10000);
    }

    document.addEventListener('DOMContentLoaded', function() {
        if (window.widgetInitialized) {
                return;
            }
            window.widgetInitialized = true;
        
        const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('launch_widget') && urlParams.get('launch_widget') === 'true') {
            
            let config = {
                "account_id": "<?php echo esc_js($this->account_id); ?>",
                "domain": "IN",
                "otherOptions": {
                    "api_key": "<?php echo esc_js($this->api_key); ?>",
                "__environment":""
                }
                
            };
            let instance = new window.ZPayments(config);
            let options = {
                "amount": "<?php echo esc_js($order->get_total()); ?>",
                "currency_code": "INR",
                "payments_session_id": "<?php echo esc_js($payment_result); ?>",
                "currency_symbol": "₹",
                "business": "<?php echo esc_js($this->business); ?>",
                "description": "Payment for order #<?php echo esc_js($this->business_desc); ?>.",
                "address": {
                    "name": "",
                    "email": ""
                }
            };
         

				// ...existing code...
    instance.requestPaymentMethod(options).then(function(data) {


    if (data.payment_id && data.signature) { // Ensure signature is present
        fetch('<?php echo esc_url( home_url('/wp-json/zpay/v1/payment_callback') ); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                order_id: '<?php echo esc_js($order_id); ?>',
                payment_id: data.payment_id,
                payment_session_id: "<?php echo esc_js($order->get_transaction_id()); ?>",
                signature: data.signature // <-- Send the signature!
            })
        })
        .then(async response => {
        const text = await response.text();
        console.log('Raw response:', text);
        try {
            const json = JSON.parse(text);
            console.log('Parsed JSON:', json);
            return json;
        } catch (err) {
            console.error('Response was not JSON:', err);
            throw new Error('Invalid JSON: ' + text.slice(0, 200)); // show first part only
        }
        }).then(apiResult => {

            console.log('API Result:', apiResult); // Debug log

            if (apiResult.success) {
                window.location.href = apiResult.redirect;
            } else {
                alert('Payment verification failed');
				// Handle error
				instance.close();
               // window.location.href = "<?php echo wc_get_cart_url(); ?>";
            }
        })
        .catch(error => {
            alert('Error calling server API: ' + error.message);
            instance.close();
        });
    }
    }).catch(function(error) {
	
    console.error("Error requesting payment method from Widget enqueue_zpay_script", error);

    fetch('<?php echo esc_url( home_url('/wp-json/zpay/v1/clear_session') ); ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': '<?php echo esc_js($zpay_nonce); ?>'
        },
        body: JSON.stringify({
            order_id: '<?php echo esc_js($order_id); ?>'
        })
    });

  
    setTimeout(function() {
     showToast("Payment widget closed or failed: " + (error && error.message ? error.message : "Unknown error"));
     instance.close();
     window.location.href = "<?php echo esc_url($order->get_view_order_url()); ?>";


    }, 5000); // Redirect after 2 seconds

    });
    }});
    </script>

<?php echo ob_get_clean();
	
	}


	public function createUserObject()
	{
    	$this->user_details = [
        	"account_id" => $this->account_id,
	        "client_id" => $this->client_id,
    	    "client_secret" => $this->client_secret,
        	"refresh_token" => $this->refresh_token,
        	"access_token" => $this->access_token,
	        "business" => $this->business,
    	    "business_desc" => $this->business_desc,
        	"name" => $this->name,
	        "email" => $this->email,
			"api_key" => $this->api_key,
			"signing_key" => $this->signing_key,
			"w_signing_key" => $this->w_signing_key,
			"data_center" => $this->data_center,
            "redirect_uri" => $this->redirect_uri
    	];
	}

    // Function to generate Zoho OAuth URL
public function get_zoho_oauth_url() {

    $client_id    = zpay_decrypt_if_needed($this->get_option('client_id'));
    $redirect_uri = $this->get_option('redirect_uri');
    $scope        = 'ZohoPay.payments.CREATE,ZohoPay.payments.READ,ZohoPay.payments.UPDATE'; // Or use $this->get_option('scope')
    $data_center  = $this->get_option('data_center');
    $soid = $this->get_option('account_id'); // Optional, if you have a specific SOID

    return "https://accounts.zoho.$data_center/oauth/v2/auth?response_type=code&client_id=$client_id&scope=$scope&access_type=offline&soid=$soid&redirect_uri=$redirect_uri";

}
	

        public function init_form_fields() {

            $this->form_fields = [
            'connect_zoho' => array(
            'type' => 'title',
            'title' => __('Zoho OAuth Connection', ZOHO_PAYMENT_GATEWAY_DOMAIN),
            'description' => '<a href="' . esc_url($this->get_zoho_oauth_url()) . '" class="button" id="zpay-connect-zoho">Connect with Zoho</a>',
            ),      
            'zoho_auth_status' => array(
                'type' => 'title',
                'title' => __('Zoho Connection Status', ZOHO_PAYMENT_GATEWAY_DOMAIN),
                'description' => $this->get_zoho_auth_status_html(),
            ),
                'data_center' => array(
				'title' => __('Data Center', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'select',
				'options' => array(
					'in' => __('IN', ZOHO_PAYMENT_GATEWAY_DOMAIN),
					'com' => __('COM', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				),
				'default' => 'in'
			),
            'redirect_uri' => array(
                'title' => __('Redirect URI', ZOHO_PAYMENT_GATEWAY_DOMAIN),
                'type' => 'text',
                'default' => esc_url(home_url('/')),
                'desc_tip' => true
            ),
			'title' => array(
				'title' => __('Title', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => __('Zoho Payment Gateway', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'desc_tip' => true
			),
			'description' => array(
				'title' => __('Description', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'textarea',
				'default' => __('Pay your invoices via Zoho Pay', ),
				'desc_tip' => true
			),
			'instruction' => array(
				'title' => __('Instructions', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'textarea',
				'default' => __('Instructions', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'desc_tip' => true
			),
			'client_id' => array(
				'title' => __('Client Id', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true
			),
			'client_secret' => array(
				'title' => __('Client Secret', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true
			),
			'refresh_token' => array(
				'title' => __('Refresh Token', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'password',
				'default' => '',
				'desc_tip' => true,
                'class' => 'zpay-sensitive-field',
                'custom_attributes' => array('readonly' => 'readonly'),
			),
			'access_token' => array(
				'title' => __('Access Token', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'password',
				'default' => '',
				'desc_tip' => true,
                'class' => 'zpay-sensitive-field',
                'custom_attributes' => array('readonly' => 'readonly'),
			
			),
			'account_id' => array(
				'title' => __('Account Id', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true
			),
			'name' => array(
				'title' => __('Name', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true
			),
			'email' => array(
				'title' => __('Email', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true
			),
			'api_key' => array(
				'title' => __('API key', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'password',
				'default' => '',
				'desc_tip' => true,
                'class' => 'zpay-sensitive-field'	
			),
			'signing_key' => array(
				'title' => __('Signing key', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'password',
				'default' => '',
				'desc_tip' => true,
                'class' => 'zpay-sensitive-field'
			),
			'w_signing_key' => array(
				'title' => __('Webhook Signing key', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'password',
				'default' => '',
				'desc_tip' => true,
                'class' => 'zpay-sensitive-field'
			),
			'business' => array(
				'title' => __('Business', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true
			),
			'business_desc' => array(
				'title' => __('Business desc', ZOHO_PAYMENT_GATEWAY_DOMAIN),
				'type' => 'text',
				'default' => '',
				'desc_tip' => true
			),
		    ];
        }

    // Public FN2 - 2 Constructor

    private static $oauth_processed = false;

    public function __construct($receiptPageFlag = true) {

        $this->id = 'zpay';
        $this->method_title = __('ZPay', 'zpay');
        $this->icon = plugin_dir_url(__FILE__) . 'images/zpay-logo.png'; 
        $this->method_description = __('ZPay Payment Gateway for WooCommerce', 'zpay');
        $this->has_fields = true;

        // Load the settings.
        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title', 'Zoho Payments');
        $this->description = $this->get_option('description', 'Zpay; you can pay with your credit card.');
        $this->instructions = $this->get_option('instructions', $this->description);
        $this->account_id    = ($this->get_option('account_id', ''));
        $this->business = $this->get_option('business');
        $this->business_desc = $this->get_option('business_desc');
        $this->email = $this->get_option('email');
        $this->name = $this->get_option('name');
        $this->data_center = $this->get_option('data_center');
        $this->redirect_uri = $this->get_option('redirect_uri', esc_url(home_url('/')));

        // Decrypt sensitive fields
        $this->client_id     = zpay_decrypt_if_needed($this->get_option('client_id', ''));
        $this->client_secret = zpay_decrypt_if_needed($this->get_option('client_secret', ''));
        $this->api_key       = zpay_decrypt_if_needed($this->get_option('api_key', ''));
        $this->signing_key   = zpay_decrypt_if_needed($this->get_option('signing_key', ''));
        $this->w_signing_key = zpay_decrypt_if_needed($this->get_option('w_signing_key', ''));
        $this->refresh_token = zpay_decrypt_if_needed($this->get_option('refresh_token', ''));
        $this->access_token  = zpay_decrypt_if_needed($this->get_option('access_token', ''));

        // Create user object
        $this->createUserObject();

  

         // Place this block after settings are loaded:
    if (
        is_admin() &&
        isset($_GET['code']) && !self::$oauth_processed
    ) {
        self::$oauth_processed = true; // Set flag so it doesn't run again
        $auth_code = sanitize_text_field($_GET['code']);
        $url = "https://accounts.zoho." . $this->data_center . "/oauth/v2/token";
        $body = [
            'grant_type' => 'authorization_code',
            'client_id' => $this->client_id,
            'client_secret' => $this->client_secret,
            'redirect_uri' => $this->redirect_uri,
            'code' => $auth_code
        ];

    
        $response = wp_remote_post($url, ['body' => $body]);
                if (is_wp_error($response)) {
                    error_log('Zoho token wp error');
                } else {
                    $result = json_decode(wp_remote_retrieve_body($response), true);
                    if (!empty($result['access_token']) && !empty($result['refresh_token'])) {
                        $settings = get_option($this->get_option_key(), []);
                        $settings['access_token'] = 'ENC:' . zpay_encrypt($result['access_token']);
                        $settings['refresh_token'] = 'ENC:' . zpay_encrypt($result['refresh_token']);
                        update_option($this->get_option_key(), $settings);
                    
                          // Build the settings page URL
                        $settings_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=zpay');
                        wp_safe_redirect($settings_url);
                    
                        add_action('admin_notices', function() {
                            echo '<div class="notice notice-success"><p>Zoho OAuth tokens saved successfully!</p></div>';
                        });
                    } else {

                        error_log('Zoho token response error');
                        add_action('admin_notices', function() use ($result) {
                            echo '<div class="notice notice-error"><p>Zoho OAuth token exchange failed: ' . esc_html(print_r($result, true)) . '</p></div>';
                        });
                    }
                }
    }
        // Save settings
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

      
        add_action('admin_enqueue_scripts', function($hook) {
            // Only load on WooCommerce settings page for your gateway
            if ($hook === 'woocommerce_page_wc-settings' && isset($_GET['section']) && $_GET['section'] === 'zpay') {
                wp_enqueue_script(
                    'zpay-admin-js',
                    plugin_dir_url(__FILE__) . 'assets/js/zpay-admin.js',
                    array('jquery'),
                    ZOHO_PAYMENT_GATEWAY_VERSION,
                    true
                );
                wp_localize_script('zpay-admin-js', 'zpay_admin_nonce', wp_create_nonce('zpay_admin_action'));
            }
        });

       
        // Actions
        // Save settings
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
       
		//add_action ( 'wc_pre_orders_process_pre_order_completion_payment_' . $this->id, array( $this, 'process_pre_order_release_payment' ), 10 );	  		

        // route post payment
		add_action('rest_api_init', function () {
			register_rest_route('zpay/v1', '/payment_callback', array(
				'methods' => 'POST',
				'callback' => 'zpay_payment_callback',
				'permission_callback' => '__return_true'

			));
		});

        //callback function for payment route
        if (!function_exists('zpay_payment_callback')) {
        function zpay_payment_callback(WP_REST_Request $request) {

            $order_id    = $request->get_param('order_id');
            $payment_id  = $request->get_param('payment_id');
            $payment_session_id = $request->get_param('payment_session_id');
            $received_signature = $request->get_param('signature'); // <-- Get the signature

            // Validate required params
            if (!$payment_id || !$order_id || !$payment_session_id || !$received_signature) {
                return new WP_Error('missing_params', __('Payment ID, Payment Session ID, Order ID, and Signature are required', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            }

            // Get your signing key from settings
            $settings = get_option('woocommerce_zpay_settings');
            $signing_key = isset($settings['signing_key']) ? zpay_decrypt_if_needed($settings['signing_key']) : '';

            if (!$signing_key) {
                error_log('Signing key is not set in the plugin settings');
                return new WP_Error('missing_signing_key', __('Signing key is not set in the plugin settings', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            }

            // Build the value string as per Zoho's server-side logic
            $value = $payment_id . '|' . $payment_session_id;

            // Generate the expected signature
            $expected_signature = hash_hmac('sha256', $value, $signing_key);

            // Compare signatures securely
            if (!hash_equals($expected_signature, $received_signature)) {
                error_log('Signature verified Failed');
                return new WP_Error('invalid_signature', __('Invalid signature. Request denied.', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            }
            else
            {
                error_log('Signature verified successfully');
                
            }
            $order = wc_get_order($order_id);
            $gateway = new WC_ZPay();
            $user_details = $gateway->user_details;

            $api_handler = new ZohoPayAPIHandler();
            $payment_result = $api_handler->verifyPayment($user_details, $order, $payment_session_id);

            error_log('Response from verifyPayment handle');

            if (!$order) {
                return new WP_Error('order_not_found', __('Order not found', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            }

            if (is_array($payment_result) && isset($payment_result['status']) && $payment_result['status'] === 'success') {
            if ($payment_result['payment_id'] == $payment_id && $payment_result['order_id'] == $order_id && $payment_result['payment_session_id'] == $payment_session_id) 
            {
            
            // Verify the amount matches
            $order_amount = floatval($order->get_total());
            $paid_amount = (isset($payment_result['amount']) && is_numeric($payment_result['amount']))
            ? floatval($payment_result['amount'])
            : null;

            if ($paid_amount === null) {
            error_log('Payment result does not contain a valid amount.');
            $order->update_status('failed', __('Payment verification failed: Amount missing or invalid', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            $order->save();
            return rest_ensure_response(['success' => false, 'redirect' => wc_get_cart_url()]);
        }

        if ($order_amount === $paid_amount) {
            $order->add_order_note(sprintf(__('Payment verified via Zoho Payments session %s Payment ID: %s', ZOHO_PAYMENT_GATEWAY_DOMAIN),  $payment_result['payment_session_id'], $payment_result['payment_id']));
            $order->update_meta_data('payment_id', $payment_id);
            $order->payment_complete($payment_id);
            $order->update_status('processing', __('Payment processed', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            $order->save();
            return rest_ensure_response(['success' => true, 'redirect' => $order->get_checkout_order_received_url()]);
        }
        else {

            error_log('Order amount mismatch: ' . $order_amount . ', got ' . $paid_amount);
            $order->update_status('failed', __('Payment verification failed: Amount mismatch', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            $order->save();
            return rest_ensure_response(['success' => false, 'redirect' => wc_get_cart_url()]);
        }

        } else {
            error_log('Payment ID mismatch');
            $order->update_status('failed', __('Payment verification failed: Payment ID mismatch', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            $order->save();
            return rest_ensure_response(['success' => false, 'redirect' => wc_get_cart_url()]);
        }
        } else {
                error_log('Payment verification failed');
                $order->update_status('failed', __('Payment verification failed', ZOHO_PAYMENT_GATEWAY_DOMAIN));
                $order->save();
                return rest_ensure_response(['success' => false, 'redirect' => wc_get_cart_url()]);
            }
        }
        }

		// Webhook listener from Zoho Payments
        add_action('rest_api_init', function () {
            register_rest_route('zpay/v1', '/webhook', array(
                'methods'  => 'POST',
                'callback' => 'zpay_webhook_handler',
                'permission_callback' => '__return_true', // You may want to add security here
            ));
        });

        if (!function_exists('zpay_webhook_handler')) {
        function zpay_webhook_handler(WP_REST_Request $request) {
            // 1. Get the signature from the header (case-insensitive)
            $signature_header = $request->get_header('x-zoho-webhook-signature');
            if (!$signature_header) {
                return new WP_Error('missing_signature', 'Missing webhook signature header', array('status' => 401));
            }

            // 2. Parse the header for t (timestamp) and v (signature)
            $matches = [];
            preg_match('/t=([0-9]+),v=([a-f0-9]+)/i', $signature_header, $matches);
            if (count($matches) !== 3) {
                return new WP_Error('invalid_signature_format', 'Invalid webhook signature format', array('status' => 401));
            }
            $timestamp = $matches[1];
            $received_signature = $matches[2];

            // 3. Get your webhook secret from settings or config
            $settings = get_option('woocommerce_zpay_settings');
            $webhook_secret = isset($settings['w_signing_key']) ? zpay_decrypt_if_needed($settings['w_signing_key']) : '';
            
            // 4. Get the raw body
            $body = $request->get_body();

            // 5. Prepare the data as "timestamp.body"
            $data = $timestamp . '.' . $body;

            // 6. Calculate the signature (HMAC SHA256, hex encoded)
            $expected_signature = hash_hmac('sha256', $data, $webhook_secret);

            // 7. Compare signatures
            if (!hash_equals($expected_signature, $received_signature)) {
                return new WP_Error('invalid_signature', 'Invalid webhook signature', array('status' => 401));
            }

            // 8. Parse the JSON body
            $data = json_decode($body, true);
            $event_type = $data['event_type'] ?? '';
            $payment = $data['event_object']['payment'] ?? [];
            $meta_data = $payment['meta_data'] ?? [];
            $order_id = null;

            // Find order_id in meta_data array
            foreach ($meta_data as $meta) {
                if (isset($meta['key']) && $meta['key'] === 'order_id') {
                    $order_id = $meta['value'];
                    break;
                }
            }

            $payment_id = $payment['payment_id'] ?? '';
            $amount = $payment['amount'] ?? '';
            $status = $payment['status'] ?? '';
            $payment_session_id = $payment['payments_session_id'] ?? '';

            if (!$order_id || !$payment_id || !$amount || !$status) {
                return new WP_Error('missing_params', 'Required parameters missing', array('status' => 400));
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                return new WP_Error('order_not_found', 'Order not found', array('status' => 404));
            }

            // Check if payment is already completed
            if ($order->is_paid()) {
                return rest_ensure_response(['success' => true, 'message' => 'Order already paid']);
            }

            // Check if payment status is already updated (processing or completed)
            $current_status = $order->get_status();
            if (in_array($current_status, ['processing', 'completed'])) {
                return rest_ensure_response(['success' => true, 'message' => 'Order payment status already updated']);
            }

            // Verify amount matches
            $order_amount = floatval($order->get_total());
            if ($order_amount != floatval($amount)) {
                return new WP_Error('amount_mismatch', 'Amount does not match order total', array('status' => 400));
            }

            // Update order status if payment is successful
            if ($event_type === 'payment.succeeded' && $status === 'succeeded') {
                $order->payment_complete($payment_id);
                $order->add_order_note('Payment completed via Zoho Payments Webhook. Payment ID: ' . $payment_id);
                $order->set_transaction_id($payment_session_id);
                $order->save();
                return rest_ensure_response(['success' => true, 'message' => 'Order payment updated']);
            } else {
                $order->update_status('failed', 'Zoho Payments Webhook reported payment failure.');
                $order->save();
                return rest_ensure_response(['success' => false, 'message' => 'Payment failed']);
            }
        }
        }


        // Clear session ID endpoint on failure cases
        add_action('rest_api_init', function () {
            register_rest_route('zpay/v1', '/clear_session', array(
                'methods' => 'POST',
                'callback' => function(WP_REST_Request $request) {
                    // Nonce authentication
                    $nonce = $request->get_header('X-WP-Nonce');
                    if (!wp_verify_nonce($nonce, 'wp_rest')) {
                        return new WP_Error('unauthorized', 'Invalid nonce', array('status' => 403));
                    }

                    $order_id = $request->get_param('order_id');
                    $order = wc_get_order($order_id);

                    if ($order) {
                        $order->update_meta_data('zpay_payment_session_id', null);
                        $order->set_transaction_id(null); // <-- Clear transaction ID
                        $order->save();
                        return rest_ensure_response(['success' => true]);
                    }
                    return new WP_Error('order_not_found', 'Order not found', array('status' => 404));
                },
                'permission_callback' => '__return_true'
            ));
        });




if ($receiptPageFlag) {

if (!has_action('woocommerce_receipt_zpay', array($this, 'receipt_page')) && $receiptPageFlag) {
	add_action('woocommerce_receipt_zpay', array($this, 'receipt_page'));
}


add_action('woocommerce_store_api_checkout_order_processed', function($order_id) {
			
			$order = wc_get_order($order_id);
			$order->update_status('on_hold', __('Awaiting Zoho payment', ZOHO_PAYMENT_GATEWAY_DOMAIN));
		
			$api_handler = new ZohoPayAPIHandler();
			$payment_result = $api_handler->complete_payment($order, $this->user_details);

            if (is_wp_error($payment_result)) {
            error_log('Payment wp error from process payment: ' . $payment_result->get_error_message());
            // Optionally update order status, add note, etc.
            return;
            }
			
		}, 10, 1);

add_action('woocommerce_order_status_pending', function($order_id) {
    $order = wc_get_order($order_id);
    if ($order) {
     error_log("Order #{$order_id} status is pending.");
    }
});

add_action('woocommerce_order_status_changed', function($order_id, $from, $to, $order) {

    error_log("ON CHANGED - Order #{$order_id} status changed from {$from} to {$to}.");

    // Only clear session ID if status changes from 'on-hold' to 'pending'
    if ($from === 'on-hold' && $to === 'pending') {
        $order->update_meta_data('zpay_payment_session_id', null);
        $order->save();
        error_log("Order #{$order_id} session ID cleared (on-hold → pending).");
    }
    // Do NOT clear if from 'draft' to 'pending'
}, 10, 4);


add_action('woocommerce_order_status_on-hold', function($order_id) {
    // Your code here
    $order = wc_get_order($order_id);
    // Example: log or update meta
    error_log("Order #{$order_id} status changed to on-hold.");
});

add_action('woocommerce_order_status_failed', function($order_id) {
    // Runs when payment fails and order status is set to 'failed'
    $order = wc_get_order($order_id);
    $order->update_meta_data('zpay_payment_session_id', null);
    error_log("Order #{$order_id} payment failed.");
});

add_action('woocommerce_order_status_processing', function($order_id) {
    // Runs when payment is completed and order status is set to 'processing'
    $order = wc_get_order($order_id);
    error_log("Order #{$order_id} payment completed (processing).");
});

add_action('woocommerce_order_status_completed', function($order_id) {
    // Runs when order status is set to 'completed'
    $order = wc_get_order($order_id);
    error_log("Order #{$order_id} marked as completed.");
});
 
add_action('woocommerce_checkout_order_processed', function($order_id) {
			
			error_log('woocommerce_checkout_order_processed fn  ---------');
			$order = wc_get_order($order_id);

			$order->update_status('on_hold', __('Awaiting Zoho payment', ZOHO_PAYMENT_GATEWAY_DOMAIN));
		
			$api_handler = new ZohoPayAPIHandler();
			$payment_result = $api_handler->complete_payment($order, $this->user_details);

            if (is_wp_error($payment_result)) {
            error_log('Payment error from complete payment: ' . $payment_result->get_error_message());
            return;
        }
		},  10, 1);


    add_action('woocommerce_thankyou', function($order_id) {
            
    });
    }	
    }	
    }

    //Register your gateway
    add_filter('woocommerce_payment_gateways', 'add_zpay_gateway');
    function add_zpay_gateway($methods) {
        $methods[] = 'WC_Zpay';
        return $methods;
    }

// FN1 - Function to create encryption key exists on activation
if (!function_exists('zpay_ensure_encryption_key')) {
function zpay_ensure_encryption_key() {
    $key = get_option('zpay_encryption_key');
    if (!$key) {
        $key = bin2hex(random_bytes(32)); // 64 hex chars = 32 bytes
        add_option('zpay_encryption_key', $key, '', 'no'); // 'no' means not autoloaded
    }
    return $key;
}
}

// FN2 - Function to get encryption key
if (!function_exists('zpay_get_encryption_key')) {
function zpay_get_encryption_key() {
    return get_option('zpay_encryption_key');
}
}

// FN3 - Function to encrypt and decrypt data
if (!function_exists('zpay_encrypt')) {
function zpay_encrypt($data) {
    $key = zpay_get_encryption_key();; // Store securely, e.g., in wp-config.php
    $method = 'AES-256-CBC';
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($method));
    $encrypted = openssl_encrypt($data, $method, $key, 0, $iv);
    return base64_encode($iv . $encrypted);
}
}

// FN4 - Function to decrypt data
if (!function_exists('zpay_decrypt')) {
function zpay_decrypt($data) {
    $key = zpay_get_encryption_key();
    $method = 'AES-256-CBC';
    $data = base64_decode($data);
    $iv_length = openssl_cipher_iv_length($method);
    $iv = substr($data, 0, $iv_length);
    $encrypted = substr($data, $iv_length);
    return openssl_decrypt($encrypted, $method, $key, 0, $iv);
}
}

// FN5 - Function to decrypt if needed
if (!function_exists('zpay_decrypt_if_needed')) {
function zpay_decrypt_if_needed($value) {
    if (strpos($value, 'ENC:') === 0) {
        return zpay_decrypt(substr($value, 4));
    }
    return $value;
}}	
}

?>
