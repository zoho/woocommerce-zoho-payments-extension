jQuery(document).ready(function($) {
    $('#zpay-generate-token').on('click', function() {
        var client_id = $('#woocommerce_zpay_client_id').val();
        var client_secret = $('#woocommerce_zpay_client_secret').val();
        var auth_code = $('#woocommerce_zpay_auth_code').val();
        var data_center = $('#woocommerce_zpay_data_center').val();

        $('#zpay-token-status').text('Generating...');

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'zpay_generate_token',
                client_id: client_id,
                client_secret: client_secret,
                auth_code: auth_code,
                data_center: data_center,
                _wpnonce: zpay_admin_nonce.value
            },
            success: function(response) {
                if (response.success) {
                    $('#zpay-token-status').text('Token generated and saved!');
                } else {
                    $('#zpay-token-status').text('Error: ' + response.data);
                }
            }
        });
    });
});