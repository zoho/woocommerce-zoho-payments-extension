<?php
if(!defined('ABSPATH'))
{
    exit('Permission Denied');
}

class ZohoPayAPIHandler
{
    public $authToken;

    // FN1 - Create Payment Session
    function createPaymentSession($order, $user_details,$auth_token_result) {

        error_log('createPaymentSession fn started ---');
        // Check if payment session ID already exists for this order
        $existing_session_id = $order->get_meta('zpay_payment_session_id', true);
        if ($existing_session_id) {
            error_log('Using existing payment session ID');
            return [
                'message' => 'success',
                'payments_session' => [
                'payments_session_id' => $existing_session_id
                ]
            ];
        }
        else
        {
            error_log('No existing payment session ID FOUND');
            
        }
        
        $data = [
            'amount' => floatval($order->get_total()),
            'currency' => $order->get_currency(),
            'meta_data'=> [
                [
                        'key'=> 'order_id',
                        "value"=> $order->get_id()
                ]
            ],
            'description'=> 'Payment for Order #' . $order->get_id(),
            'invoice_number'=> 'INV-' . $order->get_id()
            
        ];

        if (!$auth_token_result) {
            return new WP_Error('missing_access_token', __('Zoho Payments is not connected. Please contact the store admin or try again later.', ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }

        //If not type string then return error
        if (!is_string($auth_token_result)) {
            return new WP_Error('invalid_access_token', __('Invalid access token. Please contact the store admin or try again later.', ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }
    
        $options = [
            'http' => [
                'header' => "content-type: application/json\r\n" .
                        "Authorization: Zoho-oauthtoken " . $auth_token_result . "\r\n",
                'method' => 'POST',
                'content' => json_encode($data),
            ],
        ];
    
        $context = stream_context_create($options);
        $url = 'https://payments.zoho.'. $user_details['data_center'] . '/api/v1/paymentsessions?account_id=' . $user_details['account_id'];
        $response = file_get_contents($url, false, $context);

        error_log('createPaymentSession fn ended ---');
        error_log('Response: ' . $response);

        if ($response === FALSE) {
            $last_error = error_get_last();
            return new WP_Error('payment_failed', __($last_error['message'], ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }
            
        $decodedResponse = json_decode($response, true);
        if (isset($decodedResponse['error'])) {
            return new WP_Error('payment_failed', __($decodedResponse['error'], ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }

        // Store the new payment session ID in order meta
        if (isset($decodedResponse['payments_session']['payments_session_id'])) {
            $order->update_meta_data('zpay_payment_session_id', $decodedResponse['payments_session']['payments_session_id']);
            // Change status from draft to on-hold if needed
            if ($order->get_status() === 'draft') {
                $order->update_status('on-hold', __('Awaiting Zoho payment', ZOHO_PAYMENT_GATEWAY_DOMAIN));
            }
            $order->save();
        }
        return $decodedResponse; 
    }


    // FN2 - Generate Access Token from Refresh Token
    function generateAccessTokenFromRefreshToken($user_details)
    {

        $url = 'https://accounts.zoho.'. $user_details['data_center'] .'/oauth/v2/token';
        $data = http_build_query([
            'refresh_token' => $user_details['refresh_token'],
            'client_id' => $user_details['client_id'],
            'client_secret' => $user_details['client_secret'],
            'grant_type' => 'refresh_token'
        ]);

        $options = [
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'content' => $data,
                'ignore_errors' => true // Get content even on 4xx/5xx
            ]
        ];

        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);

        if ($response === FALSE) {
            $last_error = error_get_last();
            return new WP_Error('Error', __($last_error['message'], ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }
        
        $decodedResponse = json_decode($response, true);
        if (isset($decodedResponse['error'])) {
            return new WP_Error('Error', __($decodedResponse['error'], ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }

        // Check if the response contains the access token
        $this->authToken = $decodedResponse['access_token'] ?? null;
        $settings = get_option('woocommerce_zpay_settings', []);
        if (!empty($this->authToken) && strpos($this->authToken, 'ENC:') !== 0) {
        $settings['access_token'] = 'ENC:' . zpay_encrypt($this->authToken);
        } 
        else {
        $settings['access_token'] = $this->authToken;
        }
        update_option('woocommerce_zpay_settings', $settings);
        return $this->authToken;
    }

	// FN3 - Complete Payment with Retry Logic
	public function complete_payment($order, $user_details) 
	{
		error_log('complete_payment fn started -----');
 		$access_token = $user_details['access_token'] ?? '';
	
		$auth_token_result;

    	if ($access_token !== '' && $access_token !== null) {
        	$auth_token_result = $access_token; 
		} 
		else {
			$refresh_token = $user_details['refresh_token'];
			//changed
			if ($refresh_token !== '' && $refresh_token !== null) {
			error_log('Refresh token is not empty');
			$auth_token_result = $this->generateAccessTokenFromRefreshToken($user_details);	
			
			}
			else {
             error_log('Refresh token is empty');} 
		}

		if (is_wp_error($auth_token_result)) {	
        	$order->add_order_note('Auth Call failed: ' . $auth_token_result->get_error_message());
           	return $auth_token_result;
    	}

		return $this->tryPaymentSession($order,$user_details, 1,$auth_token_result );
    }

    // FN4 - Try Payment Session with Retry Logic
	public function tryPaymentSession($order, $user_details,$try,$auth_token_result)
	{
		if($try<=3)
		{
    	$result = $this->createPaymentSession($order, $user_details,$auth_token_result);

		if (is_wp_error($result)) {
            error_log("payment session creation failed for order - trial number - " . $try . " for order " . $order->get_id() . "account id: " . $user_details['account_id']);
            error_log($result->get_error_message());
            error_log("Retrying to generate new access token");
            $refresh_token = $user_details['refresh_token'];;
            $order->add_order_note('Payment Session Creation failed: ' . $result->get_error_message());	
            $auth_token_result = $this->generateAccessTokenFromRefreshToken($user_details);
			// Recursive call with incremented $try
            return $this->tryPaymentSession($order, $user_details, $try + 1, $auth_token_result);
       	}
		
		if (isset($result['message']) && $result['message'] === 'success') 
		{
			$order->add_order_note('Payment Session Created Successfully: ' . $result['payments_session']['payments_session_id']);
        	$order->update_meta_data('_paypal_status', $result['message']);
        	$order->set_transaction_id($result['payments_session']['payments_session_id']);
        	$order->save();
        	return $result['payments_session']['payments_session_id'];

    	} 
		else 
		{
			error_log("payment session creation failed again for order id: " . $order->get_id() . "account id: " . $user_details['account_id']);	   
            $order->update_meta_data('zpay_payment_session_id', null);
            $order->save();
        	return new WP_Error('payment_failed', __($result['message'], ZOHO_PAYMENT_GATEWAY_DOMAIN));
		}	
        
		}
		else
		{
          error_log("Maximum tries done - payment sessions creation failed for order id: " . $order->get_id() . "account id: " . $user_details['account_id'] . "after " . $try . " tries");
          $order->update_meta_data('zpay_payment_session_id', null);

          $order->save();
        
		}

	}
	
    
    // FN5 - Verify Payment after return from Zoho
    function verifyPayment($user_details, $order_id,$payment_session_id) 
    {
        error_log("Verify payments fn started ---");
        $options = [
            'http' => [
                'header' => "Authorization: Zoho-oauthtoken " . $user_details ['access_token'],
                'method' => 'GET'
            ],
        ];
        $context = stream_context_create($options);
        $url = 'https://payments.zoho.'. $user_details ['data_center'] .'/api/v1/paymentsessions/' . $payment_session_id . '?account_id=' . $user_details ['account_id'];
        
        $response = file_get_contents($url, false, $context);
    
        if ($response === FALSE) {
            $last_error = error_get_last();
            return new WP_Error('Retreive Error', __($last_error['message'], ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }
    
        $decodedResponse = json_decode($response, true);
        if (isset($decodedResponse['error'])) {
            return new WP_Error('Error', __($decodedResponse['error'], ZOHO_PAYMENT_GATEWAY_DOMAIN));
        }
       
        return array(
        'status' => isset($decodedResponse['message']) ? $decodedResponse['message'] : '',
        'payment_id' => isset($decodedResponse['payments_session']['payments'][0]['payment_id']) ? $decodedResponse['payments_session']['payments'][0]['payment_id'] : '',
        'payment_session_id' => $payment_session_id,
        'amount' => isset($decodedResponse['payments_session']['amount']) ? $decodedResponse['payments_session']['amount'] : '',
        'order_id' => isset($decodedResponse['payments_session']['meta_data'][0]['value']) ? $decodedResponse['payments_session']['meta_data'][0]['value'] : ''

    ); 
    }  
}
?>
